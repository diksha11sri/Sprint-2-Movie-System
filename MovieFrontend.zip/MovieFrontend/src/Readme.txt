Copy and paste css and js folders and index.html inside srx folder and 
app.component.ts inside app folder inside src