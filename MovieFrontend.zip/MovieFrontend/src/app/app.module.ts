  import { BrowserModule } from '@angular/platform-browser';
  import { NgModule } from '@angular/core';
  import { FormsModule, ReactiveFormsModule, NG_VALIDATORS } from '@angular/forms';
  import { RouterModule, Routes } from '@angular/router';
  import { HttpClientModule } from '@angular/common/http';
  import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';

  import { AuthService } from './services/auth.service';
  import { GetDataService } from './services/get-data.service'
  import { PostDataService } from './services/post-data.service'
  import { AuthGuard } from './services/auth-guard.service'
  import { AdminAuthGuard } from './services/admin-auth-guard.service'

  import { AppRoutingModule } from './app-routing.module';
  import { AppComponent } from './app.component';
  import { LoginComponent } from './login/login.component';
  import { SignupComponent } from './signup/signup.component';
  import { HomeComponent } from './home/home.component';
  import { MovieshomeComponent } from './movieshome/movieshome.component';
  import { PhonenumberDirective } from './phonenumber.directive';
  import { FiltermoviePipe } from './filtermovie.pipe';


  const routes: Routes = [
    { path: 'home', component: HomeComponent },
    { path: 'login', component: LoginComponent },
    { path: 'signup', component: SignupComponent },
    { path: 'movies', component:MovieshomeComponent },
    
  ] 
  @NgModule({
    declarations: [
      AppComponent,
      LoginComponent,
      SignupComponent,
      HomeComponent,
      MovieshomeComponent,
      PhonenumberDirective,
      FiltermoviePipe,
    
    ],
    imports: [
      BrowserModule,
      AppRoutingModule,
      FormsModule,
      HttpClientModule,
      ReactiveFormsModule,
      RouterModule.forRoot(routes),
      NgMultiSelectDropDownModule.forRoot()
    ],
    providers: [AuthService, GetDataService, PostDataService, AuthGuard, AdminAuthGuard
    ],
    bootstrap: [AppComponent]
  })
  export class AppModule { }
