 export enum BookingStatus
{
     AVAILABLE = 'AVAILABLE',
     BOOKED = 'BOOKED',
     BLOCKED ='BLOCKED',
}