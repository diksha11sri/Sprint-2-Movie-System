import { FiltermoviePipe } from './filtermovie.pipe';

describe('FiltermoviePipe', () => {
  it('create an instance', () => {
    const pipe = new FiltermoviePipe();
    expect(pipe).toBeTruthy();
  });
});
