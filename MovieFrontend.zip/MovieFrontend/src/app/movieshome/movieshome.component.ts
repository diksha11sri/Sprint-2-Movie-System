import { Component, OnInit } from '@angular/core';
import { GetDataService } from '../services/get-data.service';
import { Movie } from '../classes/Movie';
import { AuthService } from '../services/auth.service';
import { PostDataService } from '../services/post-data.service';

@Component({
  selector: 'app-movieshome',
  templateUrl: './movieshome.component.html',
  styleUrls: ['./movieshome.component.css',
    '../../css/bootstrap-grid.min.css',
    '../../css/bootstrap-reboot.min.css',
    '../../css/main.css']
})
export class MovieshomeComponent implements OnInit {

  searchMovie: string = "";
  movies:Movie[];
  isAdmin:boolean=false;
  movie: Movie;
  movieId:string;
  releaseDate: Date;
  movieName: string;
  movieGenre:string;
  movieDirector: string;
  movieLength: number;
  language: string;
  languages: string[] = [];
  isClicked:boolean;
  constructor(private getDataService : GetDataService,private postDataService: PostDataService,private authService: AuthService) 
  { }

  ngOnInit(): void {
    this.getDataService.getMovies().subscribe(data => {
      console.log(data);
      this.movies = data;
    });
    if(this.authService.userType=='Admin')
    this.isAdmin = true;
  }

    
  deleteMovie(movie:any){
  this.postDataService.deleteMovie(movie)
      .subscribe(data => {
        
      },
        (error) => {                             
          alert('Some Error occurred')

        })
      alert("Movie deleted successfully.");
      this.ngOnInit();
      location.reload();     

  }

  addMovie(){
    let id = +(this.movieId);
    this.languages = this.language.split(',');
    this.movie = new Movie(id, this.movieName, this.movieGenre, this.movieDirector, this.movieLength, this.languages, this.releaseDate);
    this.postDataService.addMovie(this.movie).subscribe(data => {    
    },
    );
    alert("Movie created successfully.");
    this.ngOnInit();
    location.reload();

  }
  
  openForm(){
    this.isClicked = true;
  }

}
