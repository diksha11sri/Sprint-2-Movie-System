  import { Injectable } from '@angular/core';
  import { HttpClient } from '@angular/common/http';
  import { Observable } from 'rxjs';
  import { Movie } from '../classes/Movie';


  @Injectable({
    providedIn: 'root'
  })
  export class GetDataService {
    private baseUrl = 'http://localhost:8050/'

    constructor(private http: HttpClient) { }

  
    getMovies() : Observable<any>{
      return this.http.get<Movie>(`${this.baseUrl}` + `movie/all`)
    }

    getMovieById(id) {
      return this.http.get(`${this.baseUrl}` + 'movie/' + id)
    }
  }
