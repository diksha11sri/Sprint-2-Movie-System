package com.cg.onlineMovieBookingSystem.Entity;

public enum BookingStatus {
	AVAILABLE, BOOKED, BLOCKED;
}
