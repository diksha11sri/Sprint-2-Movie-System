package com.cg.onlineMovieBookingSystem.repository;


import java.util.List;

import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.CrudRepository;
import com.cg.onlineMovieBookingSystem.Entity.PaymentEntity;

public interface PaymentRepository extends CrudRepository<PaymentEntity, String>{
	
	
	@Query("select c from PaymentEntity c where c.id=?1 and c.cardnumber=?2 and c.cvv=?3 and c.expiry=?4 and c.name=?5")
	public PaymentEntity credit(String id, String cardnumber, String cvv, String expiry, String name);
	
	@Query("select c from PaymentEntity c where c.id=?1 and c.cardnumber=?2 and c.cvv=?3 and c.expiry=?4 and c.name=?5")
	public PaymentEntity debit(String id, String cardnumber, String cvv, String expiry, String name);
	
	@Query("select c from PaymentEntity c where c.id=?1 and c.username=?2 and c.password=?3")
	public PaymentEntity paytm(String id, String username, String password);
	
	@Query("select c from PaymentEntity c where c.id=?1 and c.userupiid=?2 and c.password=?3")
	public PaymentEntity gpay(String id, String userupiid, String password);
	public List<PaymentEntity> findAll();
}
