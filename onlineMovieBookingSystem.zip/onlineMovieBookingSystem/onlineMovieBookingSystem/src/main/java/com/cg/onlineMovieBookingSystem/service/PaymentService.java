package com.cg.onlineMovieBookingSystem.service;

import java.util.List;

import com.cg.onlineMovieBookingSystem.Entity.PaymentEntity;



public interface  PaymentService {
	public String debit(PaymentEntity paymentEntiy);
	public String credit(PaymentEntity paymentEntiy);
	public String paytm(PaymentEntity paymentEntiy);
	public String gpay(PaymentEntity paymentEntiy);
	public String insert(PaymentEntity paymentEntiy);
	public List<PaymentEntity> findAll();
	
}