package com.cg.onlineMovieBookingSystem.service;

import java.util.List;
import java.util.NoSuchElementException;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.onlineMovieBookingSystem.Entity.PaymentEntity;
import com.cg.onlineMovieBookingSystem.repository.PaymentRepository;



@Service
@Transactional
public class PaymentServiceImpl implements PaymentService {

	
	@Autowired
	private PaymentRepository paymentRepository;
	
	@Override
	public String insert(PaymentEntity paymentEntityObj) 
	{

		paymentRepository.save(paymentEntityObj);
		return "detail inserted successfully";
	}
	
/*public String payment(PaymentEntity insert) {
	PaymentEntity cardEntity = new PaymentEntity();
		cardEntity.setId(insert.getId());
		cardEntity.setCardnumber(insert.getCardnumber());
		cardEntity.setPmode(insert.getPmode());
		cardEntity.setCvv(insert.getCvv());
		cardEntity.setExpiry(insert.getExpiry());
		cardEntity.setName(insert.getName());
		cardEntity.setUsername(insert.getUsername());
		cardEntity.setPassword(insert.getPassword());
		cardEntity.setUserupiid(insert.getUserupiid());
		paymentRepository.save(cardEntity);
		return "Payment successfull";
	}*/
	@Override
	public String debit(PaymentEntity paymentEntityObj) {
		String returnString = " Payment Successful";
		try
		{
		PaymentEntity paymentEntity = paymentRepository.findById(paymentEntityObj.getId()).get();
		if(!paymentEntityObj.getCardnumber().equals(paymentEntity.getCardnumber()))
			return "Invalid Card Number";
		if(!paymentEntityObj.getCvv().equals(paymentEntity.getCvv()))
			returnString = "Invalid CVV number";
		else if(!paymentEntityObj.getExpiry().equals(paymentEntity.getExpiry()))
			returnString = "Invalid Expiry";
		else if(!paymentEntityObj.getName().equals(paymentEntity.getName()))
			returnString = "Invalid Name";
		return returnString;
		}
		catch(NoSuchElementException ex)
		{
			return "Invalid ID";
		}
	}
	@Override
	public String credit(PaymentEntity paymentEntityObj) {
		String returnString = " Payment Successful";
		try
		{
		PaymentEntity paymentEntity = paymentRepository.findById(paymentEntityObj.getId()).get();
		if(!paymentEntityObj.getCardnumber().equals(paymentEntity.getCardnumber()))
			return "Invalid Card Number";
		else if(!paymentEntityObj.getCvv().equals(paymentEntity.getCvv()))
			returnString = "Invalid CVV number";
		else if(!paymentEntityObj.getExpiry().equals(paymentEntity.getExpiry()))
			returnString = "Invalid Expiry";
		else if(!paymentEntityObj.getName().equals(paymentEntity.getName()))
			returnString = "Invalid Name";
		return returnString;
		}
		catch(NoSuchElementException ex)
		{
			return "Invalid ID";
		}
	}
	@Override
	public String paytm(PaymentEntity paymentEntityObj) {
		String returnString = " Payment Successful";
		try
		{
		PaymentEntity paymentEntity = paymentRepository.findById(paymentEntityObj.getId()).get();
		if(!paymentEntityObj.getUsername().equals(paymentEntity.getUsername()))
			returnString = "Invalid Username";
		else if(!paymentEntityObj.getPassword().equals(paymentEntity.getPassword()))
			returnString = "Invalid Password";
			
			return returnString;
		}
		catch(NoSuchElementException ex)
		{
			return "Invalid ID";
		}
	}
	@Override
	public String gpay(PaymentEntity paymentEntityObj) {
		String returnString = " Payment Successful";
		try
		{
		PaymentEntity paymentEntity = paymentRepository.findById(paymentEntityObj.getId()).get();
		if(!paymentEntityObj.getUserupiid().equals(paymentEntity.getUserupiid()))
			return "Invalid Upi ID";
		else if(!paymentEntityObj.getPassword().equals(paymentEntity.getPassword()))
			returnString = "Invalid Password";
		return returnString;
		}
		catch(NoSuchElementException ex)
		{
			return "Invalid ID";
		}
		
	}
	@Override
	public List<PaymentEntity> findAll() {
		return paymentRepository.findAll();
	}
}
